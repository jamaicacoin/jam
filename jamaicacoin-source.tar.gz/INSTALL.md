Building JamaicaCoin
=============

See doc/build-*.md for instructions on building the various
elements of the JamaicaCoin Core reference implementation of JamaicaCoin.
